# FoldFlow Honor 0.2

Prototype for foldables, tuned for Honor Magic V6.

## Controls
- Live mode uses Android `TYPE_HINGE_ANGLE` directly (0–180°).
- Bottom slider switches to manual mode.
- Tap the top telemetry area to return to live sensor mode.
- Tap the middle of the screen to hide/show telemetry.

## Magic V6 behavior
The app shows both the raw hinge value (for example `123.1°`) and a smoothed value. Rendering follows the smoothed angle while preserving the real sensor angle as the source of truth.

## Build
Open in Android Studio with Android SDK 35 and JDK 17+ and build the `app` debug APK.

## GitHub Actions
Dit project bevat `.github/workflows/build-apk.yml`. Daarmee kan GitHub zelf `app-debug.apk` bouwen. Zie `PHONE_GITHUB_INSTRUCTIONS.md`.
