package nl.chris.foldflow;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

public class FoldWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new FoldEngine(); }

    private class FoldEngine extends Engine implements SensorEventListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private SensorManager sensorManager;
        private Sensor hinge;
        private boolean visible;
        private float targetAngle = 180f;
        private float smoothAngle = 180f;
        private long lastFrame = 0L;

        private final Runnable frameRunner = new Runnable() {
            @Override public void run() { drawFrame(); }
        };

        FoldEngine() {
            try {
                sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
                hinge = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE);
            } catch (Throwable ignored) {}
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                try {
                    if (sensorManager != null && hinge != null)
                        sensorManager.registerListener(this, hinge, SensorManager.SENSOR_DELAY_GAME);
                } catch (Throwable ignored) {}
                drawFrame();
            } else {
                handler.removeCallbacks(frameRunner);
                try { if (sensorManager != null) sensorManager.unregisterListener(this); } catch (Throwable ignored) {}
            }
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            handler.removeCallbacks(frameRunner);
            try { if (sensorManager != null) sensorManager.unregisterListener(this); } catch (Throwable ignored) {}
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onSensorChanged(SensorEvent event) {
            if (event == null || event.sensor == null || event.values == null || event.values.length == 0) return;
            if (event.sensor.getType() != Sensor.TYPE_HINGE_ANGLE) return;
            targetAngle = clamp(event.values[0], 0f, 180f);
            if (visible) drawFrame();
        }

        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

        private void drawFrame() {
            handler.removeCallbacks(frameRunner);
            if (!visible) return;

            long now = System.nanoTime();
            float dt = lastFrame == 0L ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1_000_000_000f);
            lastFrame = now;

            float diff = targetAngle - smoothAngle;
            float smoothing = 1f - (float)Math.pow(0.02, dt);
            smoothAngle += diff * smoothing;

            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) render(c, smoothAngle);
            } catch (Throwable ignored) {
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c); } catch (Throwable ignored) {}
            }

            if (Math.abs(targetAngle - smoothAngle) > 0.08f) {
                handler.postDelayed(frameRunner, 16);
            }
        }

        private void render(Canvas c, float angle) {
            int w = c.getWidth();
            int h = c.getHeight();
            if (w <= 0 || h <= 0) return;

            float open = clamp(angle / 180f, 0f, 1f);
            float closed = 1f - open;
            float cx = w * 0.5f;
            float cy = h * 0.5f;

            // Deep background gradient.
            paint.setShader(new LinearGradient(0, 0, w, h,
                    Color.rgb(20, 27, 44), Color.rgb(5, 8, 14), Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            // Large ambient glows, which slide away from the hinge as the device closes.
            float drift = closed * w * 0.11f;
            drawGlow(c, cx - w * 0.30f - drift, h * 0.22f, w * 0.55f,
                    Color.argb((int)(95 * open + 40), 97, 139, 255));
            drawGlow(c, cx + w * 0.34f + drift, h * 0.72f, w * 0.62f,
                    Color.argb((int)(80 * open + 35), 214, 91, 255));
            drawGlow(c, cx + w * 0.12f, h * 0.42f, w * 0.42f,
                    Color.argb((int)(65 + 35 * open), 54, 222, 190));

            // Refraction panels: the two halves subtly squeeze and shift as the fold closes.
            float panelInset = w * (0.055f + closed * 0.045f);
            float gap = Math.max(1f, w * (0.0025f + closed * 0.018f));
            float top = h * 0.09f;
            float bottom = h * 0.91f;
            float corner = Math.min(w, h) * 0.055f;

            RectF left = new RectF(panelInset, top + closed * h * 0.025f,
                    cx - gap, bottom - closed * h * 0.025f);
            RectF right = new RectF(cx + gap, top + closed * h * 0.025f,
                    w - panelInset, bottom - closed * h * 0.025f);

            paint.setColor(Color.argb((int)(36 + 36 * open), 255, 255, 255));
            c.drawRoundRect(left, corner, corner, paint);
            c.drawRoundRect(right, corner, corner, paint);

            // Color slabs for visible parallax/refraction.
            float blockH = h * 0.12f;
            float blockW = w * 0.26f;
            float y1 = h * 0.23f;
            float y2 = y1 + blockH + h * 0.035f;
            float slide = closed * w * 0.06f;
            drawBlock(c, cx - w * 0.30f - slide, y1, blockW, blockH, 0xAA7296FF, corner * 0.65f);
            drawBlock(c, cx + w * 0.04f + slide, y1, blockW, blockH, 0xAA60D9B2, corner * 0.65f);
            drawBlock(c, cx - w * 0.30f - slide, y2, blockW, blockH, 0xAA9A79EC, corner * 0.65f);
            drawBlock(c, cx + w * 0.04f + slide, y2, blockW, blockH, 0xAAE7A04B, corner * 0.65f);

            // Dark crease shadow grows as the angle closes.
            float crease = w * (0.002f + closed * 0.048f);
            int shadowAlpha = (int)(30 + closed * 155);
            paint.setShader(new LinearGradient(cx - crease * 2.4f, 0, cx + crease * 2.4f, 0,
                    new int[]{Color.TRANSPARENT, Color.argb(shadowAlpha, 0, 0, 0), Color.TRANSPARENT},
                    new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(cx - crease * 2.4f, 0, cx + crease * 2.4f, h, paint);
            paint.setShader(null);

            // Bright edge/reflection just to one side of the fold.
            float lightX = cx + crease * (0.6f + open * 0.5f);
            paint.setColor(Color.argb((int)(25 + closed * 125), 255, 255, 255));
            c.drawRect(lightX, h * 0.05f, lightX + Math.max(1f, w * 0.0015f), h * 0.95f, paint);

            // Subtle diagonal light sweep keyed to angle.
            float sweep = (open - 0.5f) * w * 0.35f;
            Path p = new Path();
            p.moveTo(cx - w * 0.22f + sweep, 0);
            p.lineTo(cx + w * 0.02f + sweep, 0);
            p.lineTo(cx + w * 0.32f + sweep, h);
            p.lineTo(cx + w * 0.08f + sweep, h);
            p.close();
            paint.setColor(Color.argb((int)(12 + 36 * open), 255, 255, 255));
            c.drawPath(p, paint);

            // Closing vignette gives a denser 'folding inward' feeling.
            if (closed > 0.02f) {
                paint.setColor(Color.argb((int)(closed * 75), 0, 0, 0));
                c.drawRect(0, 0, w, h, paint);
            }
        }

        private void drawGlow(Canvas c, float x, float y, float radius, int color) {
            int alpha = Color.alpha(color);
            int rgb = color & 0x00FFFFFF;
            paint.setShader(new RadialGradient(x, y, radius,
                    color, rgb, Shader.TileMode.CLAMP));
            // Ensure transparent edge regardless of rgb.
            paint.setShader(new RadialGradient(x, y, radius,
                    new int[]{color, Color.argb(alpha / 3, Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT},
                    new float[]{0f, .45f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, radius, paint);
            paint.setShader(null);
        }

        private void drawBlock(Canvas c, float x, float y, float width, float height, int color, float radius) {
            paint.setColor(color);
            c.drawRoundRect(new RectF(x, y, x + width, y + height), radius, radius, paint);
        }

        private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    }
}
