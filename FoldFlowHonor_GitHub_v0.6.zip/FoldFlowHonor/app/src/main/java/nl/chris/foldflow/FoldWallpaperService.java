package nl.chris.foldflow;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.Random;

public class FoldWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new FoldEngine(); }

    private static class Palette {
        final int bright = Color.rgb(255, 240, 196);
        final int mid = Color.rgb(201, 162, 118);
        final int soft = Color.rgb(118, 87, 58);
        final int warm = Color.rgb(255, 218, 145);
    }

    private class FoldEngine extends Engine implements SensorEventListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private final Palette palette = new Palette();
        private SensorManager sensorManager;
        private Sensor hinge;
        private boolean visible;
        private float targetAngle = 180f;
        private float smoothAngle = 180f;
        private long lastFrame = 0L;

        private final Runnable frameRunner = new Runnable() {
            @Override public void run() { drawFrame(); }
        };

        FoldEngine() {
            try {
                sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
                hinge = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE);
            } catch (Throwable ignored) {}
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                try {
                    if (sensorManager != null && hinge != null) {
                        sensorManager.registerListener(this, hinge, SensorManager.SENSOR_DELAY_GAME);
                    }
                } catch (Throwable ignored) {}
                drawFrame();
            } else {
                handler.removeCallbacks(frameRunner);
                try { if (sensorManager != null) sensorManager.unregisterListener(this); } catch (Throwable ignored) {}
            }
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            handler.removeCallbacks(frameRunner);
            try { if (sensorManager != null) sensorManager.unregisterListener(this); } catch (Throwable ignored) {}
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onSensorChanged(SensorEvent event) {
            if (event == null || event.sensor == null || event.values == null || event.values.length == 0) return;
            if (event.sensor.getType() != Sensor.TYPE_HINGE_ANGLE) return;
            targetAngle = clamp(event.values[0], 0f, 180f);
            if (visible) drawFrame();
        }

        @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

        private void drawFrame() {
            handler.removeCallbacks(frameRunner);
            if (!visible) return;

            long now = System.nanoTime();
            float dt = lastFrame == 0L ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1_000_000_000f);
            lastFrame = now;

            float diff = targetAngle - smoothAngle;
            float smoothing = 1f - (float) Math.pow(0.03, dt);
            smoothAngle += diff * smoothing;

            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) render(c, smoothAngle);
            } catch (Throwable ignored) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Throwable ignored) {}
                }
            }

            if (Math.abs(targetAngle - smoothAngle) > 0.08f) {
                handler.postDelayed(frameRunner, 16);
            }
        }

        private void render(Canvas c, float angle) {
            final int w = c.getWidth();
            final int h = c.getHeight();
            if (w <= 0 || h <= 0) return;

            final float open = clamp(angle / 180f, 0f, 1f);
            final float closed = 1f - open;
            final float cx = w * 0.5f;
            final float cy = h * 0.455f;

            paint.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{Color.rgb(2, 3, 6), Color.rgb(8, 9, 15), Color.rgb(2, 3, 6)},
                    new float[]{0f, .52f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            // dark center space for icon readability
            float clearWidth = w * (0.12f + 0.10f * open);
            paint.setShader(new LinearGradient(cx - clearWidth, 0, cx + clearWidth, 0,
                    new int[]{Color.TRANSPARENT, Color.argb((int)(130 * open + 35), 0, 0, 0), Color.TRANSPARENT},
                    new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(cx - clearWidth, 0, cx + clearWidth, h, paint);
            paint.setShader(null);

            // primary light source morphs from cover screen origin to unfolded center hinge origin
            float sx = lerp(-w * 0.06f, cx, open);
            float sy = lerp(h * 0.47f, cy, open);

            drawAmbientGlow(c, sx, sy, lerp(w * 0.28f, w * 0.18f, open), Color.argb((int)(140 + 60 * open), 255, 228, 165));
            drawAmbientGlow(c, sx, sy, lerp(w * 0.52f, w * 0.32f, open), Color.argb((int)(38 + 40 * open), 190, 138, 80));

            drawStreakField(c, w, h, sx, sy, open);

            // hinge crease and reflection grow as it closes
            float creaseW = w * (0.002f + 0.030f * closed);
            if (creaseW > 0.5f) {
                paint.setShader(new LinearGradient(cx - creaseW * 2.8f, 0, cx + creaseW * 2.8f, 0,
                        new int[]{Color.TRANSPARENT, Color.argb((int)(150 * closed), 0, 0, 0), Color.TRANSPARENT},
                        new float[]{0f, .5f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(cx - creaseW * 2.8f, 0, cx + creaseW * 2.8f, h, paint);
                paint.setShader(null);

                paint.setColor(Color.argb((int)(80 * closed), 255, 255, 255));
                c.drawRect(cx + creaseW * 0.6f, h * 0.04f, cx + creaseW * 0.8f + 2f, h * 0.96f, paint);
            }

            // subtle glass bands so the fold feels physical, but not too strong.
            if (closed > 0.02f) {
                paint.setColor(Color.argb((int)(closed * 40), 255, 255, 255));
                c.drawRoundRect(new RectF(w * 0.06f, h * 0.10f, cx - w * 0.02f, h * 0.90f), w * 0.05f, w * 0.05f, paint);
                c.drawRoundRect(new RectF(cx + w * 0.02f, h * 0.10f, w * 0.94f, h * 0.90f), w * 0.05f, w * 0.05f, paint);
            }

            // Top and search-bar readability masks.
            paint.setShader(new LinearGradient(0, 0, 0, h * 0.17f,
                    new int[]{Color.argb(118, 0, 0, 0), Color.TRANSPARENT},
                    new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h * 0.17f, paint);
            paint.setShader(null);

            float searchY = h * 0.70f;
            float searchH = h * 0.085f;
            paint.setColor(Color.argb(30, 255, 255, 255));
            c.drawRoundRect(new RectF(w * 0.11f, searchY, w * 0.89f, searchY + searchH), searchH * 0.33f, searchH * 0.33f, paint);

            // vignette
            paint.setShader(new RadialGradient(cx, h * 0.50f, Math.max(w, h) * 0.82f,
                    new int[]{Color.TRANSPARENT, Color.argb(75, 0, 0, 0)},
                    new float[]{0.55f, 1f}, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
        }

        private void drawStreakField(Canvas c, int w, int h, float sx, float sy, float open) {
            Random random = new Random(20260918L);
            float cx = w * 0.5f;
            float angleDrift = (1f - open) * 0.10f;
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);

            // Main streaks
            for (int i = 0; i < 260; i++) {
                float t = random.nextFloat();
                float closedX = w * (0.18f + 0.90f * random.nextFloat());
                float closedY = h * random.nextFloat();

                boolean leftSide = random.nextBoolean();
                float openX;
                if (leftSide) openX = cx - w * (0.06f + 0.44f * random.nextFloat());
                else openX = cx + w * (0.06f + 0.44f * random.nextFloat());
                float openY = h * random.nextFloat();

                float ex = lerp(closedX, openX, open);
                float ey = lerp(closedY, openY, open);

                // keep a calmer center channel on large screen
                if (open > 0.6f) {
                    float distToCenter = Math.abs(ex - cx) / w;
                    if (distToCenter < 0.06f && ey < h * 0.90f) {
                        ex += ex < cx ? -w * 0.06f : w * 0.06f;
                    }
                }

                int alpha = (int) lerp(36f, 95f, 1f - Math.abs(0.5f - t));
                if (random.nextFloat() < 0.18f) alpha += 45;
                alpha = Math.min(alpha, 165);

                int color;
                float palettePick = random.nextFloat();
                if (palettePick < 0.14f) color = Color.argb(alpha, 255, 239, 201);
                else if (palettePick < 0.42f) color = Color.argb(alpha, 235, 198, 138);
                else if (palettePick < 0.82f) color = Color.argb(alpha, 184, 138, 92);
                else color = Color.argb(alpha / 2, 255, 252, 235);

                float width = lerp(0.8f, 4.6f, random.nextFloat() * random.nextFloat());
                line.setColor(color);
                line.setStrokeWidth(width);

                Path path = new Path();
                path.moveTo(sx, sy);
                float mx = lerp(sx, ex, 0.35f) + (ex - sx) * angleDrift;
                float my = lerp(sy, ey, 0.35f);
                path.quadTo(mx, my, ex, ey);
                c.drawPath(path, line);
            }

            // brighter accent ribbons
            for (int i = 0; i < 22; i++) {
                float side = (i % 2 == 0 || open < 0.35f) ? 1f : -1f;
                float exClosed = w * (0.20f + 0.75f * random.nextFloat());
                float exOpen = cx + side * w * (0.14f + 0.26f * random.nextFloat());
                float ey = h * (0.30f + 0.40f * random.nextFloat());
                float ex = lerp(exClosed, exOpen, open);

                line.setColor(Color.argb((int) lerp(85f, 170f, open), 255, 233, 170));
                line.setStrokeWidth(lerp(7f, 16f, random.nextFloat()));

                Path ribbon = new Path();
                ribbon.moveTo(sx, sy);
                float mx = lerp(sx, ex, 0.30f);
                float my = lerp(sy, ey, 0.30f) + h * (random.nextFloat() - 0.5f) * 0.08f;
                ribbon.quadTo(mx, my, ex, ey);
                c.drawPath(ribbon, line);
            }
        }

        private void drawAmbientGlow(Canvas c, float x, float y, float radius, int color) {
            paint.setShader(new RadialGradient(x, y, radius,
                    new int[]{color, Color.argb(Color.alpha(color) / 3, Color.red(color), Color.green(color), Color.blue(color)), Color.TRANSPARENT},
                    new float[]{0f, .42f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(x, y, radius, paint);
            paint.setShader(null);
        }

        private float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
        private float lerp(float a, float b, float t) { return a + (b - a) * t; }
    }
}
