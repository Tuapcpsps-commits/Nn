package nl.chris.foldflow;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor hinge;
    private TextView angleText;
    private TextView sensorText;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(8, 8, 10));
        getWindow().setNavigationBarColor(Color.rgb(8, 8, 10));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(42), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(8, 8, 10));

        TextView title = label("FoldFlow", 34, true, Color.WHITE);
        root.addView(title);

        TextView subtitle = label("Nova-vriendelijke live wallpaper voor je Magic V6", 16, false, Color.rgb(183, 171, 154));
        root.addView(subtitle, margin(0, dp(6), 0, 0));

        angleText = label("—°", 60, true, Color.rgb(255, 241, 209));
        angleText.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(angleText, margin(0, dp(42), 0, 0));

        sensorText = label("Hingesensor controleren…", 14, false, Color.rgb(149, 140, 126));
        sensorText.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(sensorText, margin(0, dp(4), 0, 0));

        TextView info = label(
                "Deze versie is afgestemd op jouw goud-zwarte achtergrond en Nova-layout. De wallpaper verandert live tijdens het vouwen, maar laat je iconen verder met rust.",
                15, false, Color.rgb(214, 209, 201));
        info.setLineSpacing(0, 1.2f);
        root.addView(info, margin(0, dp(36), 0, 0));

        Button setButton = button("Live wallpaper instellen");
        setButton.setOnClickListener(v -> openWallpaperPreview());
        root.addView(setButton, margin(0, dp(30), 0, 0));

        Button pickerButton = button("Wallpaperkiezer openen");
        pickerButton.setOnClickListener(v -> {
            try { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
            catch (Throwable ignored) { openWallpaperSettings(); }
        });
        root.addView(pickerButton, margin(0, dp(12), 0, 0));

        TextView note = label("Let op: Android laat de achtergrond wel mee bewegen, maar niet de echte Nova-iconen zelf.", 12, false, Color.rgb(120, 114, 104));
        note.setLineSpacing(0, 1.15f);
        root.addView(note, margin(0, dp(32), 0, 0));

        setContentView(root);

        try {
            sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            hinge = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE);
            if (hinge == null) sensorText.setText("Geen hingesensor gevonden");
            else sensorText.setText("HONOR HINGE SENSOR • LIVE");
        } catch (Throwable t) {
            sensorText.setText("Sensorcontrole mislukt");
        }
    }

    private void openWallpaperPreview() {
        try {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, FoldWallpaperService.class));
            startActivity(intent);
        } catch (Throwable t) {
            try { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
            catch (Throwable ignored) { openWallpaperSettings(); }
        }
    }

    private void openWallpaperSettings() {
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Throwable ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        try {
            if (sensorManager != null && hinge != null)
                sensorManager.registerListener(this, hinge, SensorManager.SENSOR_DELAY_UI);
        } catch (Throwable ignored) {}
    }

    @Override protected void onPause() {
        try { if (sensorManager != null) sensorManager.unregisterListener(this); } catch (Throwable ignored) {}
        super.onPause();
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event == null || event.values == null || event.values.length == 0) return;
        if (event.sensor == null || event.sensor.getType() != Sensor.TYPE_HINGE_ANGLE) return;
        float angle = Math.max(0f, Math.min(180f, event.values[0]));
        angleText.setText(String.format(Locale.US, "%.1f°", angle));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private TextView label(String s, int sp, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(39, 32, 25));
        b.setPadding(dp(14), dp(12), dp(14), dp(12));
        return b;
    }

    private LinearLayout.LayoutParams margin(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
